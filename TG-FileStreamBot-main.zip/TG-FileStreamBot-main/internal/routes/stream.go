package routes

import (
	"EverythingSuckz/fsb/internal/bot"
	"EverythingSuckz/fsb/internal/stream"
	"EverythingSuckz/fsb/internal/types"
	"EverythingSuckz/fsb/internal/utils"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"

	"github.com/gotd/td/tg"
	range_parser "github.com/quantumsheep/range-parser"
	"go.uber.org/zap"

	"github.com/gin-gonic/gin"
)

var log *zap.Logger

func (e *allRoutes) LoadHome(r *Route) {
	log = e.log.Named("Stream")
	defer log.Info("Loaded stream route")
	r.Engine.GET("/stream/:messageID", getStreamRoute)
	r.Engine.GET("/watch/:messageID", getWatchRoute)
}

func getWatchRoute(ctx *gin.Context) {
	messageIDParm := ctx.Param("messageID")
	authHash := ctx.Query("hash")
	streamURL := fmt.Sprintf("/stream/%s?hash=%s&raw=true", messageIDParm, authHash)
	directDownloadURL := fmt.Sprintf("/stream/%s?hash=%s&d=true", messageIDParm, authHash)

	htmlContent := fmt.Sprintf(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Watch Video - Drama World BD</title>
    <link rel="stylesheet" href="https://cdn.plyr.io/3.7.8/plyr.css" />
    <style>
        body, html {
            margin: 0;
            padding: 0;
            width: 100%%;
            height: 100%%;
            background-color: #000;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow: hidden;
        }
        .player-container {
            width: 100%%;
            height: 100%%;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #000;
        }
        .plyr {
            width: 100%%;
            height: 100%%;
        }
        
        /* Mobile Progress bar max space optimize */
        @media (max-width: 600px) {
            .plyr__volume {
                display: none !important; /* মোবাইলে অডিও স্লাইডার হাইড করে প্রোগ্রেস বার বড় করা */
            }
            .plyr__controls .plyr__progress__container {
                flex: 1 1 auto !important;
                min-width: 0 !important;
            }
            .plyr__time--current, .plyr__time--duration {
                font-size: 11px !important;
                padding: 0 4px !important;
            }
            .plyr__controls button {
                padding: 5px !important;
            }
        }

        /* Mobile VIP Modal */
        .vip-modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%%;
            height: 100%%;
            background: rgba(0, 0, 0, 0.85);
            backdrop-filter: blur(4px);
            z-index: 999999;
            justify-content: center;
            align-items: center;
            padding: 10px;
            box-sizing: border-box;
        }
        .vip-card {
            position: relative;
            background: #181a20;
            color: #fff;
            width: 95%%;
            max-width: 380px;
            max-height: 90vh;
            overflow-y: auto;
            padding: 20px 15px;
            border-radius: 10px;
            text-align: center;
            border: 1px solid #e50914;
            box-shadow: 0 5px 25px rgba(0,0,0,0.8);
            box-sizing: border-box;
        }
        .close-corner-btn {
            position: absolute;
            top: 8px;
            right: 10px;
            background: #333;
            color: #fff;
            border: none;
            width: 26px;
            height: 26px;
            border-radius: 50%%;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .vip-card h3 {
            color: #ff3344;
            margin: 4px 0 6px 0;
            font-size: 17px;
        }
        .vip-card p {
            color: #bbb;
            font-size: 12px;
            line-height: 1.4;
            margin: 0 0 12px 0;
        }
        .btn-vip {
            display: block;
            background: #e50914;
            color: #fff;
            padding: 9px 12px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            font-size: 13px;
            margin-bottom: 8px;
        }
        .btn-free {
            width: 100%%;
            background: #232733;
            color: #00d2d3;
            border: 1px solid #00d2d3;
            padding: 9px 12px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            font-size: 13px;
            box-sizing: border-box;
        }
    </style>
</head>
<body>

<div class="player-container">
    <video id="player" playsinline preload="auto" controls>
        <source src="%s" type="video/mp4">
    </video>
</div>

<div id="vipModal" class="vip-modal-overlay" onclick="handleBackdropClick(event)">
    <div class="vip-card" id="vipCard">
        <button class="close-corner-btn" onclick="closeModal()">✕</button>
        <div style="font-size: 24px; margin-bottom: 2px;">👑</div>
        <h3>VIP মেম্বারশিপ প্রয়োজন!</h3>
        <p>
            সরাসরি হাই-স্পিড ডাউনলোড সুবিধাটি শুধুমাত্র আমাদের <strong>VIP মেম্বারদের</strong> জন্য। ফ্রি ডাউনলোডের জন্য নিচে দেখুন।
        </p>
        <a href="https://dramaworldbd.topbanglanewspaper.com/subscribe/" target="_top" class="btn-vip">
            ⭐ Buy VIP Membership
        </a>
        <button onclick="goToFreeDownload()" class="btn-free">
            📥 ফ্রি ডাউনলোড লিঙ্ক দেখুন
        </button>
    </div>
</div>

<script src="https://cdn.plyr.io/3.7.8/plyr.polyfilled.js"></script>
<script>
    const directDownloadLink = "%s";
    let isUserLoggedIn = false;

    window.addEventListener("message", function(event) {
        if (event.data && event.data.type === "WP_USER_STATUS") {
            isUserLoggedIn = event.data.isLoggedIn;
        }
    });

    // Fast Load Player with Unmuted Audio
    const player = new Plyr('#player', {
        autoplay: true,
        muted: false,
        volume: 1,
        controls: ['play-large', 'play', 'progress', 'current-time', 'volume', 'captions', 'settings', 'pip', 'download', 'fullscreen']
    });

    // Instant Fast Autoplay Execution
    const videoEl = document.getElementById('player');
    videoEl.muted = false;
    
    player.on('canplay', () => {
        const playPromise = player.play();
        if (playPromise !== undefined) {
            playPromise.catch(() => {
                // ব্রাউজার অটোপ্লে বাধা দিলে একবার মিউট করে চালু করবে
                player.muted = true;
                player.play();
            });
        }
    });

    if (window.parent) {
        window.parent.postMessage({ type: "CHECK_WP_AUTH" }, "*");
    }

    // Intercept Download
    player.on('ready', () => {
        const downloadBtn = document.querySelector('a[data-plyr="download"], button[data-plyr="download"]');
        if (downloadBtn) {
            downloadBtn.removeAttribute('href');
            downloadBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();

                if (isUserLoggedIn) {
                    window.location.href = directDownloadLink;
                } else {
                    document.getElementById('vipModal').style.display = 'flex';
                }
            });
        }
    });

    function closeModal() {
        document.getElementById('vipModal').style.display = 'none';
    }

    function handleBackdropClick(e) {
        if (e.target.id === 'vipModal') {
            closeModal();
        }
    }

    function goToFreeDownload() {
        closeModal();
        if (window.parent) {
            window.parent.postMessage({ type: "SCROLL_TO_BOTTOM" }, "*");
        }
    }
</script>
</body>
</html>`, streamURL, directDownloadURL)

	ctx.Header("Content-Type", "text/html; charset=utf-8")
	ctx.String(http.StatusOK, htmlContent)
}

func getStreamRoute(ctx *gin.Context) {
	w := ctx.Writer
	r := ctx.Request

	userAgent := r.Header.Get("User-Agent")
	acceptHeader := r.Header.Get("Accept")
	if ctx.Query("raw") != "true" && ctx.Query("d") != "true" && strings.Contains(acceptHeader, "text/html") && !strings.Contains(userAgent, "curl") {
		getWatchRoute(ctx)
		return
	}

	messageIDParm := ctx.Param("messageID")
	messageID, err := strconv.Atoi(messageIDParm)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	authHash := ctx.Query("hash")
	if authHash == "" {
		http.Error(w, "missing hash param", http.StatusBadRequest)
		return
	}

	worker := bot.GetNextWorker()

	file, err := utils.TimeFuncWithResult(log, "FileFromMessage", func() (*types.File, error) {
		return utils.FileFromMessage(ctx, worker.Client, messageID)
	})
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	expectedHash := utils.PackFile(
		file.FileName,
		file.FileSize,
		file.MimeType,
		file.ID,
	)
	if !utils.CheckHash(authHash, expectedHash) {
		http.Error(w, "invalid hash", http.StatusBadRequest)
		return
	}

	if file.FileSize == 0 {
		res, err := worker.Client.API().UploadGetFile(ctx, &tg.UploadGetFileRequest{
			Location: file.Location,
			Offset:   0,
			Limit:    1024 * 1024,
		})
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		result, ok := res.(*tg.UploadFile)
		if !ok {
			http.Error(w, "unexpected response", http.StatusInternalServerError)
			return
		}
		fileBytes := result.GetBytes()
		ctx.Header("Content-Disposition", fmt.Sprintf("inline; filename=\"%s\"", file.FileName))
		if r.Method != "HEAD" {
			ctx.Data(http.StatusOK, file.MimeType, fileBytes)
		}
		return
	}

	ctx.Header("Accept-Ranges", "bytes")
	var start, end int64
	rangeHeader := r.Header.Get("Range")

	if rangeHeader == "" {
		start = 0
		end = file.FileSize - 1
		w.WriteHeader(http.StatusOK)
	} else {
		ranges, err := range_parser.Parse(file.FileSize, r.Header.Get("Range"))
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		start = ranges[0].Start
		end = ranges[0].End
		ctx.Header("Content-Range", fmt.Sprintf("bytes %d-%d/%d", start, end, file.FileSize))
		log.Info("Content-Range", zap.Int64("start", start), zap.Int64("end", end), zap.Int64("fileSize", file.FileSize))
		w.WriteHeader(http.StatusPartialContent)
	}

	contentLength := end - start + 1
	mimeType := file.MimeType

	if mimeType == "" {
		mimeType = "application/octet-stream"
	}

	ctx.Header("Content-Type", mimeType)
	ctx.Header("Content-Length", strconv.FormatInt(contentLength, 10))

	disposition := "inline"

	if ctx.Query("d") == "true" {
		disposition = "attachment"
	}

	ctx.Header("Content-Disposition", fmt.Sprintf("%s; filename=\"%s\"", disposition, file.FileName))

	if r.Method != "HEAD" {
		pipe, err := stream.NewStreamPipe(ctx, worker.Client, file.Location, start, end, log)
		if err != nil {
			log.Error("Failed to create stream pipe", zap.Error(err))
			return
		}
		defer pipe.Close()
		if _, err := io.CopyN(w, pipe, contentLength); err != nil {
			if !utils.IsClientDisconnectError(err) {
				log.Error("Error while copying stream", zap.Error(err))
			}
		}
	}
}
